---
title        : What to do in preparation for a Threat Model
track        : Governance
project      : Risk and Governance
type         : working-session
topics       :
featured     :
event        : mini-summit
when_year    : 2021
when_month   : May
when_day     : Mon
when_time    : WS-3
hey_summit   : https://post-summit-sessions.heysummit.com/talks/what-to-do-in-preparation-for-a-threat-model/
session_slack:
#status       : draft
description  :
organizers   :
    - Petra Vukmirovic
    - Abbas Haidar
    - Chris Holman
youtube_link : 9i43haujgVs
zoom_link    : 
---

## About this session

Petra, Abbas and Chris are going to be presenting the guidance provided to developers
before threat modeling sessions
