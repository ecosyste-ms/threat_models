# Jaeger Threat Model

This is a placeholder for the Jaeger Threat Model. This will be based on [OSSF standards](https://github.com/ossf/security-insights-spec/tree/main/docs/threat-model) and examples of existing threat models. This is a significant chunk of work for Jaeger due to the diversity and complexity of all the supported components in deployment. 