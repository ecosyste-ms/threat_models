---
index: 114
title: Modelo de amenazas
---
# Modelo de amenaza 

Una manera de pensar en forma estrecha sobre los tipos de protección que desea para sus datos. Es imposible protegerse contra todo tipo de truco o ataque, por lo que debe concentrarse en qué personas podrían querer sus datos, qué podrían querer de ellos y cómo podrían obtenerlos. Venir con un conjunto de posibles ataques a los que planea proteger se llama modelado de amenazas. Una vez que tenga un modelo de amenaza, puede realizar un análisis de riesgo.