A list of previous and current research into defining a threat framework especially for automotive.

A number of models have been used to determine the threats to automotive assets. These models include:

<b>TARA</b>

Threat analysis and risk assessment.


<b>STRIDE</b><p></p>
This model was developed within Microsoft and stands for:
<l>
<li>Spoof</li>
<li>Tamper</li>
<li>Repudiation</li>
<li>Information disclosure</li>
<li>Denial of service</li>
<li>Escalation of privilege</li>
</l>

<p></p>
<b>EVITA</b>
e-safety vehicle intrusion protected 
<p></p>
<b>PIER</b>
<l>
<li>Probability</li>
<li>Impact</li>
<li>Exposure</li>
<li>Recovery</li>
</l>

<p></p>


<b>Supply chain threat</b>

A number of supply chain attacks have brought this vulnerability to the forefront, especially in software.
<l>
<li>unkown pedigree</li>
<li>counterfeit</li>
<li>malicious code</li>
</l>
<p></p>

<b> Open source threat</b>


After the log4J incident, there is more focus on the pedigree of software and where it comes from.
<l>
<li> out of date</li>
<li>not maintained</li>
<li>vulnerabilities</li>
<li>bug fixing</li>
</l>


