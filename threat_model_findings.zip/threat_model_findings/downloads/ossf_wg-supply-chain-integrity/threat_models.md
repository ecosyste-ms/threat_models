# Threat Models

This document contains the detailed threat models we feel are in scope for this working group.

Coming soon. Currently in Google doc form: https://docs.google.com/document/d/1gixyDvA0DppCDGhgzmTDxIADry7KTvldqdYO0oad2V8/edit#