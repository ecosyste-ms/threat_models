# AutoThreatModel

CLI to generate STRIDE threat models from YAML files.
Status: CLI scaffold built, refining output format.