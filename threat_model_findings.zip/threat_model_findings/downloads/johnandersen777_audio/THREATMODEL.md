# Threat Model

## What we need to protect

* WiFi ssid's and passwords
* Code on device

## Who are we protecting it from

* Mosad

## How are we protecting these things

* Config file
  * No protections
* Code on device
  * TODO: Disable REPL console over UART and WebREPL
