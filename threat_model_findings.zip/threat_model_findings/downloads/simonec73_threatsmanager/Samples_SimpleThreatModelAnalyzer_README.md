# SimpleThreatModelAnalyzer

A very simple host for the Threats Manager Platform Engine.

The important part is in the ModelLoader class:

- The constructor initializes the Engine.
- OpenModel opens the model and parses it.
