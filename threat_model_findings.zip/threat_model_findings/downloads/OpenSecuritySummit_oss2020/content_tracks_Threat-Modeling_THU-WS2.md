---
title        : Threatmodel tool demos - Thursday PM
type         : user-session
track        : "Threat Modeling"
category     :
featured     :                 # if  "yes" review with summit team
when_day     : Thu
when_time    : WS-2
hey_summit   : https://open-security-summit-2020.heysummit.com/talks/threatmodel-tool-demos-thursday-pm-2pm-bst/
room_layout  :
room_id      : 
session_slack: 
status       : 
description  : Tool demos
participants :
organizers   :
    - Steven Wierckx
    - Stuart Winter-Tear
    - Alex Bauert
    - Nikunj Nagalia
hosted_by    : Alona Reyes
slide_id     : 2PACX-1vTNzF_YmYAeqEf7Mv_j4xxFKPHupsYjf8gvok4QMNqEpNy1n1bSgWBBSz7OtYWqk6PDHSGJajlaDoL_
slide_edit   : 1GJTZldlU_-ogevRNyfYGjbDf5_TKY8auAxU1jbptKC0
participants :
youtube_link : https://www.youtube.com/watch?v=EQ14YdYZt54


---

## Session content

{{<pdf src="https://github.com/OpenSecuritySummit/oss2020/raw/master/content/outcomes/presentation/VAST%20ONE%20SHEET.pdf">}}
    
https://go.threatmodeler.com/process-flow-diagrams-vs-data-flow-diagrams-with-modern-threat-modeling

## Why
When choosing a threat model tool, you first need to know what the tool can and cannot do. In order to facilitate this we are organising a number of demonstrations of tools, each 30 minutes long.

## What
Tool 1: Threatmodeler by Stuart Winter-Tear, Alex Bauert and Nikunj Nagalia
http://www.threatmodeler.com/


## Outcomes
A recording of the functionalities at the moment of the summit


