# ThreatModel - Automated Security Analysis Workflow

![Threat Model Workflow](Screenshot%202025-06-08%20at%2022.43.33.png)

## Overview

ThreatModel is an n8n workflow that automates security threat modeling for software projects. The workflow allows users to submit a Google Doc containing project specifications through a form, processes it with Google Gemini's AI, and delivers a comprehensive security analysis report directly to the requester's email.

## Key Features

- **Web Form Submission**: Simple interface to submit project information
- **Google Docs Integration**: Reads project documentation directly from Google Docs
- **AI-Powered Analysis**: Uses Google Gemini to perform sophisticated threat modeling
- **Structured Security Analysis**:
  - STRIDE methodology (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)
  - PASTA framework (Process for Attack Simulation and Threat Analysis)
  - OWASP Top 10 vulnerabilities mapping
  - Common Weakness Enumeration (CWE) references
- **HTML Report Delivery**: Delivers formatted reports via email

## Workflow Components

1. **Form Trigger**: Collects requester email, project name, and Google Doc link
2. **Google Docs Node**: Extracts content from the provided document link
3. **Google Gemini Chat Model**: Powers the AI analysis
4. **Basic LLM Chain**: Processes the document content with specialized security prompts
5. **Code Node**: Formats the HTML output for readability
6. **Gmail Node**: Delivers the formatted threat model to the requester

## How to Use

1. Deploy the workflow in your n8n instance
2. Share the generated form link with your team
3. Users submit project documentation via Google Doc URLs
4. The requester receives a detailed threat model analysis via email within minutes

## Required API Credentials

- Google Docs API credentials (for accessing submitted documents)
- Google Gemini API key (for AI analysis)
- Gmail API access (for sending reports)

## Example Output

The generated threat model includes:

- Detailed vulnerability analysis using STRIDE methodology
- PASTA-based attack vectors and impact analysis
- OWASP Top 10 vulnerability mappings
- CWE references for identified weaknesses
- Specific recommendations for security improvements

## Setup Instructions

1. Import `ThreatModel.json` into your n8n instance
2. Configure the required API credentials:
   - Google Docs OAuth2 API
   - Google Gemini (PaLM) API
   - Gmail OAuth2
3. Activate the workflow
4. Test by submitting a sample project document

## Use Cases

- Security review for new software projects
- Preliminary security assessment before implementation
- Identifying potential security flaws in existing designs
- Educational tool for teaching threat modeling concepts

---

Built with n8n and Google Gemini AI. Last updated: June 2025.