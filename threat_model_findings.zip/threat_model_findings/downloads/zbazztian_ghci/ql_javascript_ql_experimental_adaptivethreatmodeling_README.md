# [Internal only] Adaptive Threat Modeling for JavaScript

This directory contains CodeQL libraries and queries that power adaptive threat modeling for JavaScript.
All APIs are experimental and may change in the future.

These queries can only be run by internal users; for external users they will return no results.
