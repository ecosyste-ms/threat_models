# Threat Model for Dexicon Extension

This document outlines the threat model for the Dexicon browser extension, including its frontend components and backend API. The goal is to identify potential security vulnerabilities, describe existing mitigations, and recommend improvements.

## 1. System Architecture

The system consists of two main components:

1.  **Browser Extension (Frontend)**: A React-based extension that runs in the user's browser. It captures selected text, displays definitions and AI-generated content, and manages user settings.
2.  **Backend API**: A Cloudflare Worker (`api.djregister-50.workers.dev`) that acts as a secure proxy to the OpenAI API and handles user authentication and validation via ExtensionPay.

## 2. Authentication and Authorization

The core of the security model revolves around ensuring that only authenticated users with valid subscriptions or trials can access paid features, primarily the AI-powered capabilities.

-   **Mechanism**: Authentication is handled through an `extensionpay_api_key` provided by the ExtensionPay service upon user signup, trial, or purchase. This key is the primary credential.
-   **Storage**: The `extensionpay_api_key` is stored in `chrome.storage.sync` on the client-side.
-   **Validation Flow**:
    1.  The frontend sends the `extensionpay_api_key` to the backend for any request requiring authorization.
    2.  The backend's `getAndCacheUserValidation` function validates this key by communicating securely with the ExtensionPay API.
    3.  For performance, successful validation results (linking an API key to a user's email and paid status) are cached in Cloudflare KV for 1 hour.
    4.  The `useProcessedUser` hook in the frontend periodically re-validates the user's status with the `/verify-credentials` backend endpoint, ensuring the frontend's view of the user's access rights is synchronized with the backend's source of truth.

-   **Vulnerabilities & Mitigations**:
    -   **Threat**: An attacker steals a user's `extensionpay_api_key`.
    -   **Mitigation**: The key is stored in sandboxed browser storage, which is protected by the browser's security model from being accessed by other websites. While other malicious extensions could potentially access it, this relies on the user installing untrusted software. The key is only transmitted over HTTPS to the trusted backend.

## 3. API Security (Backend)

The Cloudflare Worker is the most critical component from a security perspective as it controls access to the costly OpenAI service.

#### 3.1. Unauthorized Access & API Abuse

-   **Threat**: An unauthorized user attempts to call the OpenAI proxy, or an authorized user abuses their access by sending an excessive number of requests, leading to high operational costs (Denial of Service / Cost Escalation).
-   **Mitigations**:
    1.  **API Key Validation**: Every request to the OpenAI proxy endpoint requires a valid `extensionpay_api_key`, which is validated by the backend against the ExtensionPay service. This is a strong control against unauthorized access.
    2.  **CORS Policy**: The backend enforces a CORS policy that restricts allowed methods to `POST` and `OPTIONS` and specifies allowed headers, reducing the attack surface.
    3.  **(High Priority) Rate Limiting & Monthly Quotas**: This threat is now **fully mitigated** by a stateful, backend-enforced rate-limiting system.
        -   **Implementation**: A Cloudflare Durable Object (`MonthlyRateLimiter`) is used to track each user's request count.
        -   **Identifier**: Usage is tied to the user's canonical email address (retrieved from ExtensionPay), providing a stable identifier.
        -   **Atomicity**: Durable Objects guarantee atomic read-modify-write operations on the request counter, preventing race conditions that could allow a user to exceed their quota.
        -   **Enforcement**: If a user exceeds their `MONTHLY_REQUEST_LIMIT`, the backend returns a `429 Too Many Requests` error, and no call is made to the OpenAI API. The frontend is designed to handle this error and display a message to the user.

#### 3.2. Input Validation and Prompt Injection

-   **Threat**: A user crafts a malicious input (`word`, `passage`, `meaningsForAI`) to "jailbreak" the system prompt sent to OpenAI. This could cause the AI to ignore its instructions, reveal its underlying prompt, or generate inappropriate content.
-   **Mitigations**:
    1.  **Structured Prompts**: The backend uses specific, hardcoded system prompts for each `responseType`. User input is embedded as data within these prompts, not as instructions. This is a best practice for mitigating prompt injection.
    2.  **Parameter Validation**: The backend validates that required parameters (`word`, `passage`, etc.) are present for the requested `responseType`.

-   **Identified Weakness & Recommendation**:
    -   **Weakness**: The backend does not seem to enforce length limits on user-provided strings (`word`, `passage`). An attacker could send extremely long passages, leading to unexpectedly high token usage and cost per API call.
    -   **Recommendation (Medium Priority)**: Add backend validation to enforce a reasonable maximum length (e.g., 5,000 characters) for all user-provided input fields before they are sent to OpenAI.

## 4. Frontend Security

-   **Threat**: Cross-Site Scripting (XSS) from AI-generated content. If the AI response contains malicious HTML/JavaScript and it is rendered without sanitization, it could execute in the context of the extension.
-   **Mitigation**: The frontend is built with React, which automatically escapes data rendered within JSX. This provides strong, default protection against XSS as long as `dangerouslySetInnerHTML` is not used (and it is not used in the current codebase).

## 5. Data Privacy

-   **Data Handled**:
    -   **PII**: User's email address.
    -   **Contextual Data**: Text selected by the user (`word`) and its surrounding passage (`passage`).
-   **Data Flow**: This data is sent to the backend API, and then the contextual data is forwarded to the OpenAI API for processing. The user's email is **never** sent to OpenAI.
-   **Mitigations**:
    -   All data is transmitted over HTTPS.
    -   The backend does not store or log the `passage` or `word` content.
-   **Recommendation**:
    -   Create a formal Privacy Policy that is easily accessible to users. It should clearly state what data is collected (email, text content), why it's collected (to provide the service and enforce quotas), and with which third parties it is shared (OpenAI). This is crucial for user trust and transparency.

## 6. Summary of Recommendations

1.  **(Mitigated) Backend Rate Limiting & Usage Quotas**: This was the highest priority and is now complete.
2.  **(Medium Priority) Implement Backend Input Length Validation**: Protect against abnormally long and expensive API calls by enforcing maximum length limits on user-provided text.
3.  **(Low Priority) Create a Formal Privacy Policy**: Build user trust and be transparent about data handling practices by providing a clear and comprehensive privacy policy. 