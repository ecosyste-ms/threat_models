# bHermesBoost

- [constructor](#function-constructor)
- [mint](#function-mint)


## Function: `constructor`

The function initializes the owner address and `bHermes` address.

## Function: `mint`

ERC20 mint function can be called only by `bHermes` address.

