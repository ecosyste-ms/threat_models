### Index

- [UlyssesFactory](UlyssesFactory.md)
  - [createPool(ERC20 asset, address owner)](UlyssesFactory.md#function-createpoolerc20-asset-address-owner)
  - [createToken(uint256[] poolIds, uint256[] weights, address owner)](UlyssesFactory.md#function-createtokenuint256-poolids-uint256-weights-address-owner)