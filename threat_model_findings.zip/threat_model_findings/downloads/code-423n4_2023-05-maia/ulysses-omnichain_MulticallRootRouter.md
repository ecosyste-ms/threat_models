# MulticallRootRouter

- [initialize(address _bridgeAgentAddress)](#function-initializeaddress-_bridgeagentaddress)

## Function: `initialize(address _bridgeAgentAddress)`

The function can only be called once. Allows owner to initialize the `bridgeAgentAddress` address and reset ownership.

