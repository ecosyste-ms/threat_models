# TalosStrategyVanillaFactory

The contract is inherited from `TalosBaseStrategyFactory`. See the `TalosBaseStrategyFactory` description.

