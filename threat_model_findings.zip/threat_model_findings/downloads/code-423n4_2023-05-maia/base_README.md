### Index

- [FlywheelCore](FlywheelCore.md)
  - [accrue(ERC20 strategy, address user)](FlywheelCore.md#function-accrueerc20-strategy-address-user)
  - [accrue(ERC20 strategy, address user, address secondUser)](FlywheelCore.md#function-accrueerc20-strategy-address-user-address-seconduser)
  - [accrueStrategy(ERC20 strategy, uint256 state)](FlywheelCore.md#function-accruestrategyerc20-strategy-uint256-state)
  - [accrueUser(ERC20 strategy, address user, uint256 index)](FlywheelCore.md#function-accrueusererc20-strategy-address-user-uint256-index)
  - [claimRewards(address user)](FlywheelCore.md#function-claimrewardsaddress-user)
  - [addStrategyForRewards(ERC20 strategy)](FlywheelCore.md#function-addstrategyforrewardserc20-strategy)
  - [setFlywheelRewards(address newFlywheelRewards)](FlywheelCore.md#function-setflywheelrewardsaddress-newflywheelrewards)
  - [setBooster(IFlywheelBooster newBooster)](FlywheelCore.md#function-setboosteriflywheelbooster-newbooster)