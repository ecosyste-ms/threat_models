# FlywheelCoreInstant

- [constructor](#function-constructor)


## Function: `constructor`

The contract is created inside the `TalosStrategyStakedFactory:constructor()` with a zero `flywheelBooster` address. The `TalosStrategyStakedFactory` contract is the owner of this contract. Additionally, the `FlywheelCore` contract is initialized here.

