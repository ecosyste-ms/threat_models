### Index

- [MultiRewardsDepot](MultiRewardsDepot.md)
  - [addAsset(address rewardsContract, address asset)](MultiRewardsDepot.md#function-addassetaddress-rewardscontract-address-asset)
  - [getRewards()](MultiRewardsDepot.md#function-getrewards)
  - [removeAsset(address rewardsContract)](MultiRewardsDepot.md#function-removeassetaddress-rewardscontract)
- [SingleRewardsDepot](SingleRewardsDepot.md)
  - [getRewards()](SingleRewardsDepot.md#function-getrewards)