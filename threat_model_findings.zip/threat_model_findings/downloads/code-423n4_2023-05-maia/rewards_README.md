### Index

- [FlywheelInstantRewards](FlywheelInstantRewards.md)
  - [getAccruedRewards()](FlywheelInstantRewards.md#function-getaccruedrewards)
- [FlywheelAcummulatedRewards](FlywheelAcummulatedRewards.md)
  - [getAccruedRewards](FlywheelAcummulatedRewards.md#function-getaccruedrewards)
- [FlywheelGaugeRewards](FlywheelGaugeRewards.md)
  - [queueRewardsForCycle](FlywheelGaugeRewards.md#function-queuerewardsforcycle)
  - [queueRewardsForCyclePaginated](FlywheelGaugeRewards.md#function-queuerewardsforcyclepaginated)
  - [getAccruedRewards](FlywheelGaugeRewards.md#function-getaccruedrewards)
- [FlywheelBribeRewards](FlywheelBribeRewards.md)
  - [constructor](FlywheelBribeRewards.md#function-constructor)
  - [setRewardsDepot](FlywheelBribeRewards.md#function-setrewardsdepot)