### Index

- [bHermesVotes](bHermesVotes.md)
  - [burn(address from, uint256 amount)](bHermesVotes.md#function-burnaddress-from-uint256-amount)
  - [mint(address to, uint256 amount)](bHermesVotes.md#function-mintaddress-to-uint256-amount)
- [bHermesGauges](bHermesGauges.md)
  - [constructor()](bHermesGauges.md#function-constructor)
  - [mint()](bHermesGauges.md#function-mint)
  - [mint](bHermesGauges.md#function-mint)
- [HERMES](HERMES.md)
  - [mint(address account, uint256 amount)](HERMES.md#function-mintaddress-account-uint256-amount)
- [bHermesBoost](bHermesBoost.md)
  - [constructor](bHermesBoost.md#function-constructor)
  - [mint](bHermesBoost.md#function-mint)