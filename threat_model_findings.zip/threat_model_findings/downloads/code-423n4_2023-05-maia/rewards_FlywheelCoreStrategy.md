# FlywheelCoreStrategy

- [constructor](#function-constructor)


## Function: `constructor`

The contract is created inside the `BribesFactory:createBribeFlywheel()` function with a nonzero `flywheelBooster` address. The `BribesFactory` contract is the owner of this contract. Additionally, the `FlywheelCore` contract is initialized here.

