### Index

- [BaseV2Minter](BaseV2Minter.md)
  - [fallback()](BaseV2Minter.md#function-fallback)
  - [getRewards()](BaseV2Minter.md#function-getrewards)
  - [initialize(FlywheelGaugeRewards \_flywheelGaugeRewards)](BaseV2Minter.md#function-initializeflywheelgaugerewards-_flywheelgaugerewards)
  - [setDaoShare(uint256 \_daoShare)](BaseV2Minter.md#function-setdaoshareuint256-_daoshare)
  - [setDao(address \_dao)](BaseV2Minter.md#function-setdaoaddress-_dao)
  - [setTailEmission(uint256 \_tail_emission)](BaseV2Minter.md#function-settailemissionuint256-_tail_emission)
  - [updatePeriod()](BaseV2Minter.md#function-updateperiod)