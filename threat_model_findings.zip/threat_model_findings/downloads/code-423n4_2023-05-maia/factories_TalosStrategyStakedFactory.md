# TalosStrategyStakedFactory

- [constructor](#function-constructor)


## Function: `constructor`

Initialize a new `FlywheelCoreInstant` contract with a zero `flywheelBooster` contract address and set this contract's address as the `owner`. Then, initialize the `FlywheelInstantRewards` contract with the created `FlywheelCoreInstant` contract and set this new `FlywheelInstantRewards` contract as the `rewardToken` inside the `FlywheelCoreInstant`.

