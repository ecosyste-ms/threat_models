# TalosManager

- [performUpkeep(byte[] None)](#function-performupkeepbyte-none)


## Function: `performUpkeep(byte[] None)`

Triggers a rebalance or rerange on the strategy if required.

### Branches and code coverage

**Intended branches**

- A rebalance is required and is triggered.
  - [ ] Test coverage
- A rearrange is required and is triggered.
  - [ ] Test coverage

