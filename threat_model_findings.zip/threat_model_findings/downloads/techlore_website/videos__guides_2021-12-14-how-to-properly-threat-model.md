---
title: "How to PROPERLY threat model"
description: "How to threat model - one of the most misunderstood concepts in the entire privacy & security community. Welcome to our complete guide to it!"
datePublished: 2021-12-14
dateUpdated: 2021-12-14
linkYouTube: "https://www.youtube.com/watch?v=DHZRhboZhfI"
linkPeerTube: "https://techlore.tv/w/udSHSNcpWB5WBWqVp3tDRA"
tags: ["threatmodel", "privacy", "security"]
---
