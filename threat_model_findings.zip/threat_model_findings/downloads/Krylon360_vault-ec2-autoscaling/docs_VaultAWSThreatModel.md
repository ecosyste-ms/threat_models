# Vault/AWS threat model
