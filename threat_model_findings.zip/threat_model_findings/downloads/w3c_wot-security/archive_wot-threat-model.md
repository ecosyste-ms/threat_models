## WoT Threat Model

The WoT threat model material has been moved to the 
[WoT Security and Privacy Considerations](index.html#wot-threat-model) document.

