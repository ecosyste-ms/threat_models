# Threat Actors (TA)

| ID   | Description        |
|------|--------------------|
| TA01 | External attacker. |
| TA02 | Internal attacker. |
