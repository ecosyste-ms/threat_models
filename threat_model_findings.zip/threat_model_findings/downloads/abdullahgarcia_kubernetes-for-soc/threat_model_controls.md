# Controls (C)

| ID  | Description                                   |
|-----|-----------------------------------------------|
| C01 | C-Harden-Component                            |
| C02 | C-Control-Traffic-Flow                        |
| C03 | C-Harden-Config-Compl-Mon / C-Mon-Drift       |
| C04 | C-Evt-Log-App / C-Evt-Log-Sec / C-Evt-Log-Sys |
| C05 | C-Mon-File-Integrity                          |
| C06 | C-Mon-Log                                     |
| C07 | C-Mon-Health                                  |
| C08 | C-Vuln-Scan                                   |
| C09 | C-K8s-Harden-Component                        |
| C10 | C-K8s-AdmissionControllers                    |
| C11 | C-K8s-AuditLogs                               |
| C12 | C-K8s-Authorisation                           |
| C13 | C-K8s-CNI-NetworkPolicies                     |
| C14 | C-K8s-MutatingAdmissionController             |
| C15 | C-K8s-ValidationAdmissionController           |
| C16 | C-K8s-Encryption                              |
| C17 | C-K8s-ContainerRuntimeSecurity                |
| C18 | C-K8s-Authentication                          |
