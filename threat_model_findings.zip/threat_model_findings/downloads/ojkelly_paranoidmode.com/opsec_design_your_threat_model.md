# Design your threat model

See also https://ssd.eff.org/en/module/introduction-threat-modeling
