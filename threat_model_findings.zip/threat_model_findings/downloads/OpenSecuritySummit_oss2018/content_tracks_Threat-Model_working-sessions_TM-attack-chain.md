---
title        : Attack chains as TM technique
type         : working-session
track        : Threat Model
technology   :
categories   :                      # GDPR, Juice Shop, etc.
featured     : yes                    # review with summit team "yes"
when_day     : Tue
when_time    : PM-2
room_layout  :                    #
room_id      : room-1
session_slack: https://os-summit.slack.com/messages/CAUSLQKRQ
status       : done              # draft, review-content, done
organizers   : ["Steven Wierckx"]
description  : Threat Modeling Working Session
locked       : true
participants :
  - Adam Shostack
---

## WHY

We need different techniques to discover threats against a system to complement the traditional ones if they do not work.

## What

Create attack chains as TM technique. Extedend possibly using DFD as connection maps, layered defence and attack patterns.

## Outcomes

An example of an attack chain.

## References
