---
title        : Threat model closing session
type         : working-session
technology   :
categories   :                     # GDPR, Juice Shop, etc.
featured     : yes                  # review with summit team "yes"
when_day     : Fri
when_time    : PM-3
room_layout  :                    #
room_id      : room-1
session_slack: https://os-summit.slack.com/messages/CB0LV47V0
status       : done              # draft, review-content, done
organizers   : Steven Wierckx
description  : Threat Modeling Working Session
track        : Threat Model
locked       : true
participants :
     - Adam Shostack
---

## WHY

     To list our achievements and agree on the way forward.

## What

 1. List our achievements for this summit
 2. Agree on the way forward
 3. Distribute tasks


## Outcomes

 List of achievements

## References
