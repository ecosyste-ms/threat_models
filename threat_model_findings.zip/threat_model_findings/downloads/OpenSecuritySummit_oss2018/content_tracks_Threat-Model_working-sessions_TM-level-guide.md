---
title        : Threat model guide
type         : working-session
technology   :
categories   :                      # GDPR, Juice Shop, etc.
featured     : yes                   # review with summit team "yes"
when_day     : Thu
when_time    : PM-1
room_layout  :                    #
room_id  : room-1
session_slack: https://os-summit.slack.com/messages/CB1N876EB
status       : done              # draft, review-content, done
organizers   : Steven Wierckx
description  : Threat model guide with levels
track        : Threat Model
locked       : true
participants:
   - Adam Shostack
---

## WHY

People are clueless on how to start with threat modeling. I propos we create a guide i the style of ASVS where we show in different levels what the steps are that can be done for threat modeling depending on the need and/or maturity of the organisation.

## What

 A guide with some levels such as:
 level 0: you are not doing TM or something ad hoc
 level 1: you are answering some of the 4 questions but not in a structured way
 level 2: you do a full 4 question TM for one product
 level 3: you intregated the full TM in the SDLC and vary the amount/level of the TM according to the risk appetite of that application/system/product

## Outcomes

The table of contents for the guide and some content.

## References

https://www.owasp.org/index.php/Category:OWASP_Application_Security_Verification_Standard_Project
