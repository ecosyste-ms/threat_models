## Amenazas 5G Principales
- **gNodeB Spoofing**: Emulación de estaciones base falsas.
- **Network Slicing Attacks**: Aislamiento de segmentos de red.
