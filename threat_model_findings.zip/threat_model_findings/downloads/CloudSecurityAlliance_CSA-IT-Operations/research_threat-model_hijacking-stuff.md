# Things that can be hijacked

```mermaid
graph LR;
    BGP;
    DNS_Name_servers;
    DNS_Content;
    User_Email_Address;
    User_Social_media;
    User_Service_provider;
    Admin_Social_media;
    Admin_Service_provider;
```
