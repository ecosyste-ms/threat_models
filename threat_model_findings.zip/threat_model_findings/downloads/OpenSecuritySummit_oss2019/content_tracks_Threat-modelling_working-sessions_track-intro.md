---
title        : TM track introduction
type         : working-session
track        : Threat Model
topics       : 
technology   :
categories   :  Threat modeling                    # GDPR, Juice Shop, etc.
featured     : yes                   # review with summit team "yes"
when_day     : Mon
when_time    : PM-1
room_layout  :                    #
room_id      : room-3
session_slack: https://os-summit.slack.com/messages/CAVPAADAA
status       : review-content             # draft, review-content, done
organizers   :
    - Steven Wierckx
participants :
description  : Introduction of the TM track and way of working for this week
locked       : true
---

## Why

In order to get the most from this summit and the threat model track we will give a short introduction on our way of working and discuss all planned sessions. any new and refreshing ideas can then be added to the backlog so we can choose topics that have a large support within the community.
This session is meant for all participants who are new to threat modeling and/or new to the summit or threat model track.

## What

 - Welcome
 - Our way of working
 - Publishing data
 - Track sessions

## Outcomes

 - Set objectives for the Summit
 - Discussed project structure
 - Discussed any crossover with other OWASP projects
 - Identified list of sub-modules to create in OWASP project
