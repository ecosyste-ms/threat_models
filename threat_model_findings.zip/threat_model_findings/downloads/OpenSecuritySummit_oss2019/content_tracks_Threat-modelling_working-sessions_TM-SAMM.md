---
title        : SAMMv2 - Threat Modeling
type         : working-session
track        : Threat Model
locked       : true
technology   :
categories   :                      # GDPR, Juice Shop, etc.
featured     :                    # review with summit team "yes"
when_day     : Thu
when_time    : PM-2
room_layout  :                    #
room_id      : room-3
session_slack: https://os-summit.slack.com/messages/CAWEU9CRM
status       : review-content              # draft, review-content, done
description  : Discuss the SAMM threat modeling practice together with the SAMM team
organizers   :
    - Steven Wierckx
    - Sebastien Deleersnyder
participants:
    - Bart De Win
---

This session will be dedicated to align the SAMM threat modeling practice between the 2 tracks

Session Requirements: Familiarity with the SAMM v1.5 and v2 model
