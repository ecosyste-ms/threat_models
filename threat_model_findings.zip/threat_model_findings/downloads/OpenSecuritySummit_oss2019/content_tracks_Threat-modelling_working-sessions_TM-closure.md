---
title        : Track closure
type         : working-session
track        : Threat Model
topics       : 
technology   :
categories   :                      # GDPR, Juice Shop, etc.
featured     : yes                   # review with summit team "yes"
when_day     : Thu
when_time    : PM-3
room_layout  :                    #
room_id      : room-3
session_slack: https://os-summit.slack.com/messages/CAVPAADAA
status       : done             # draft, review-content, done
organizers   :
    - Steven Wierckx
participants :
description  : Track closure
locked       : true
---

## What

Just a wrap up of what we achieved this week, a call for volunteers to finish items etc.

