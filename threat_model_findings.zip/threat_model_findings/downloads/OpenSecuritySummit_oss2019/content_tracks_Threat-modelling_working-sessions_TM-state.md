---
title        : State and future of threat modeling
type         : working-session
track        : Threat Model
topics       : 
technology   :
categories   :                      # GDPR, Juice Shop, etc.
featured     : yes                   # review with summit team "yes"
when_day     : Wed
when_time    : AM-1
room_layout  :                    #
room_id      : room-3
session_slack: https://os-summit.slack.com/messages/CAVPAADAA
status       : review-content             # draft, review-content, done
organizers   :
    - Steven Wierckx
description  : What is the current state of TM and where do we need to go?
locked       : true
---

## Why

What is the current state of threat modeling? Are there any new and exciting things happening? What is needed for the future?

## Outcomes

A curated note of the content discussed.
