# OpenAPI-Spec for a small threat modelling solution.

This API defines services for managing a threat model.
