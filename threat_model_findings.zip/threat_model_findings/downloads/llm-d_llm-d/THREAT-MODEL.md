# llm-d Threat Model

This is a placeholder for the llm-d Threat Model. This will be based on [OSSF standards](https://github.com/ossf/security-insights-spec/tree/main/docs/threat-model) and examples of existing threat models. This is a significant chunk of work for llm-d due to the diversity and complexity of all the supported components in deployment. 