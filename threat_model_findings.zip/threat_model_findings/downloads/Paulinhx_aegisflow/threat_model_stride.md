| Component | STRIDE Threat | Description                      |
| --------- | ------------- | -------------------------------- |
| `/eval`   | Tampering     | Unsanitized code input           |
| `/pickle` | Spoofing, EoP | Arbitrary object deserialization |
| `/shell`  | Execution     | OS command injection             |
