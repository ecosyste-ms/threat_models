
# threat model

who is attacker

what do they want

what are assets

how are they protected : forward privacy

types of attacks
1. privilege escalation
2. Denial of service
3. information leakage

what is compromise SOP
1. key revocation

